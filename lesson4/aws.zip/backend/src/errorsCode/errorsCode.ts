export const STATUS = {
    CODE_404: 404,
    CODE_401: 401,
    CODE_400: 400,
    CODE_500: 500,
    CODE_403: 403,
    CODE_201: 201,
};
