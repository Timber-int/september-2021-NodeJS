export * from './student';
export * from './teacher';
