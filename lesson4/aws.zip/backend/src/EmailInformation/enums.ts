export enum EmailActionEnum {
    // eslint-disable-next-line no-unused-vars
    LOGIN,
    // eslint-disable-next-line no-unused-vars
    LOGOUT,
    // eslint-disable-next-line no-unused-vars
    REGISTRATION,
    // eslint-disable-next-line no-unused-vars
    FORGOT_PASSWORD,
    // eslint-disable-next-line no-unused-vars
    CHANGE_PASSWORD,
    // eslint-disable-next-line no-unused-vars
    SEND_SURPRISE_MESSAGE
}
