export const baseURL = 'api';

export const urls = {
    users: '/users',
    auth: '/auth',
    registration: '/registration',
};
